﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uz_2
{
	class Kambarys
	{
		public int KambarioKlase;
		public bool Uzimta;
		public int UzimtasLaikasValandomis;
		public int VietuSkaicius;
		public double KainaZmogui;
		public string KambarioAprasymas;
		public bool Nesutvarkytas;
		public int ApsigyvenusiuZmoniuSkaicius;

		public Kambarys()
		{ 
		
		}
		public void Uzimti()
		{ 
		
		}

		public void Sutvarkyti()
		{

		}

		public void Apmoketi()
		{ 
		
		}

		public void Informacija()
		{ 
		
		}
	
	}
	class Program
	{
		static void Main(string[] args)
		{
		}
	}
}
